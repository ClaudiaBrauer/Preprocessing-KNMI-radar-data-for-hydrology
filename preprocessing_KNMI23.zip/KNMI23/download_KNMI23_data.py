#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Python script to download files from the KNMI Data Platform (KDP) for the KNMI23 scenarios
# Based on an example script from https://www.knmi.nl/kennis-en-datacentrum/achtergrond/modeluitvoer-knmi-23-klimaatscenario-s
# and slightly expanded by Claudia Brauer.
#
# To use:
# Change the directory (L. 20) to the folder where the downloaded files will be stored
# and specify which variable and scenario you want (L.23-26).
# Then run line by line (F9). Result is a folder per day with h5 files (of each 5 minutes)
# (and a tar file per day if you comment L. 90). 

# Import Python libraries:
import logging
import os
import sys
import requests

# SET WORKING DIRECTORY HERE (no spaces allowed)
os.chdir("C:/KNMI/KNMI23/PE_all")

# CHANGE WHICH FILES YOU WANT HERE
var = 'pet'      # options: Pr = precipitation, pet = ETpot
year = 2033      # options: 2033, 2050, 2100, 2150
scen = 'H'       # options: H = high, M = moderate, L = low
variant = ''    # options: n = wet, d = dry. For 2033, there is no n/d division, so use ''

# these don' work:
# pet+pr Ld 2050+2150 
# pet+pr Ln 2050+2150
# for 2033 only L




scenario = f'{scen}{variant}_{year}'
file = f'{var}_{scenario}_interp.nc'
file_ref = f'{var}_ref_interp.nc'

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(os.environ.get("LOG_LEVEL", logging.INFO))

class OpenDataAPI:
    def __init__(self, api_token: str):
        self.base_url = "https://api.dataplatform.knmi.nl/open-data/v1"
        self.headers = {"Authorization": api_token}
    def __get_data(self, url, params=None):
        return requests.get(url, headers=self.headers, params=params).json()
    def list_files(self, dataset_name: str, dataset_version: str, params: dict):
        return self.__get_data(
                f"{self.base_url}/datasets/{dataset_name}/versions/{dataset_version}/files",
                params=params,
        )
    def get_file_url(self, dataset_name: str, dataset_version: str, file_name: str):
        return self.__get_data(
            f"{self.base_url}/datasets/{dataset_name}/versions/{dataset_version}/files/{file_name}/url"
    )


def download_file_from_temporary_download_url(download_url, filename):
    try:
        with requests.get(download_url, stream=True) as r:
            r.raise_for_status()
            with open(filename, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
    except Exception:
        logger.exception("Unable to download file using download URL")
        sys.exit(1)

    logger.info(f"Successfully downloaded dataset file to {filename}")



api_key = "eyJvcmciOiI1ZTU1NGUxOTI3NGE5NjAwMDEyYTNlYjEiLCJpZCI6ImE1OGI5NGZmMDY5NDRhZDNhZjFkMDBmNDBmNTQyNjBkIiwiaCI6Im11cm11cjEyOCJ9" # public key (Jan 2024)
dataset_name = "knmi23_user_friendly_racmo"
dataset_version = "2.0"

api = OpenDataAPI(api_token=api_key)

if not os.path.isfile(file):
    logger.info(f"Fetching {file} of {dataset_name} version {dataset_version}")
    response = api.get_file_url(dataset_name, dataset_version, file)
    download_file_from_temporary_download_url(response["temporaryDownloadUrl"], file)
    
if not os.path.isfile(file_ref):
    logger.info(f"Fetching {file} of {dataset_name} version {dataset_version}")
    response = api.get_file_url(dataset_name, dataset_version, file_ref)
    download_file_from_temporary_download_url(response["temporaryDownloadUrl"], file_ref)


