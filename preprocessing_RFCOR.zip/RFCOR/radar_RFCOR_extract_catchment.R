

#################
# Getting started
#################

# Clear workspace
rm(list=ls())

# Set working directory 
setwd("C:/KNMI")

# Uncomment to install packages if needed.
# To install rhdf5 package without having to install Rtools first:
# install.packages("BiocManager")
# BiocManager::install("rhdf5")

# Load packages
library(terra)      
library(sf)         
library(rhdf5)



########################
# Coordinates all pixels
########################

# Load ascii file with dataframe with radar pixel coordinates (in lat-lon)
pix_all_df = read.table("RFCOR/coordinates/radarcoordinaten_NL25_1km2_RD.txt")  

# Convert to spatial object (SpatVect class): put x and y in dataframe, set projection
pix_all_df$ID = 1:nrow(pix_all_df)
pix_all_sp = vect(cbind(longitude = pix_all_df[,3]*1000, latitude = pix_all_df[,4]*1000), 
                 atts = data.frame(ID = pix_all_df$ID, drow = pix_all_df[,1], dcol = pix_all_df[,2]), 
                 crs="+init=epsg:28992")

# Check (don't plot because too heavy)
pix_all_sp



################
# Catchment area
################

# Load border NL
NL_RD = vect("catchment_boundary/NL_border.shp", crs="+init=epsg:28992")  

# Reproject
NL_latlon = terra::project(NL_RD, "+proj=longlat +datum=WGS84")
NL_latlon

# Plot country map
plot(NL_latlon, border="grey")

# Define ID of catchment
cat_ID = "Aa"

# Option 1 :Load shapefile with catchment boundary (in RD coordinates)
cat_RD = vect(paste0("catchment_boundary/", cat_ID, "_catchment_boundary.shp"), 
              crs="+init=epsg:28992")  

# Change coordinate system RD to LatLon
cat_latlon = terra::project(cat_RD, "+proj=longlat +datum=WGS84")

# Option 2: Define x and y coordinates of the extent
# Order of arguments: xmin, xmax, ymin, ymax
# cat_latlon = vect(ext(3.3, 7.5, 50.7, 53.6), crs="+proj=longlat +datum=WGS84")

# Check
cat_latlon
lines(cat_latlon, col="darkblue")



############################
# Select pixels in catchment
############################

# Cut out the pixels within the catchment
pix_cat_sp = intersect(pix_all_sp, cat_RD)

# Check
pix_cat_sp

# Make dataframe with the ID, lat and lon, row and col
pix_cat_df     = data.frame(ID = pix_cat_sp$ID)
pix_cat_df$lat = crds(pix_cat_sp)[,2]
pix_cat_df$lon = crds(pix_cat_sp)[,1]
pix_cat_df$row = pix_cat_sp$drow
pix_cat_df$col = pix_cat_sp$dcol

# Write to file
write.table(pix_cat_df, paste0("RFCOR/coordinates/pixels_", cat_ID, ".dat"), row.names=F)

# Reproject to latlon
pix_cat_RD = vect(pix_cat_df, crs="+init=epsg:28992")
pix_cat_latlon = terra::project(pix_cat_RD, "+proj=longlat +datum=WGS84")

# Add pixels to map
points(pix_cat_latlon, cex=0.1, col="dodgerblue")

# Write to file
write.table(pix_cat_df,paste0("RFCOR/coordinates/pixels_",cat_ID, ".dat"),row.names=F)

# Save figure to file
pdf(paste0("RFCOR/coordinates/map_",cat_ID,".pdf"), width=5, height=6, family="Times")
plot(NL_latlon, border="grey", main=paste("RFCOR pixels",cat_ID), xlab="Lon", ylab="Lat")
lines(cat_latlon, col="darkblue")
points(pix_cat_latlon, cex=0.1, col="dodgerblue")
graphics.off()



################
# Read HDF5 data
################

# Specify for which year
year = 2023

# Make vector with all 1 hour intervals in that year
steps = seq(from = ISOdatetime(year, 1, 1, 0, 0, 0, tz = "UTC"),  # year, month, day, hour, minute, second
           to = ISOdatetime(year + 1, 1, 1, 0, 0, 0, tz = "UTC"), 
           by = "5 min")
# Cut off last value (is first value of next year)
steps = steps[1:(length(steps)-1)]

# Transform into 'YYYYmmddHHMM' format
steps = as.numeric(format(steps, "%Y%m%d%H%M"))

# Also subtract day
day        = steps%/%10000

# In a folder for a certain day there are files from 8:05 that day to 8:00 the next day
idx_morning = which(steps%%10000 <= 800)
idx_morning[idx_morning < 24*12] = 24*12+1  # to avoid negative indices - file does not exist
folder_day  = day
folder_day[idx_morning] = day[idx_morning - 24*12]

# Make matrix for precipitation of all hours (rows) and all pixels (cols)
P_cat = matrix(nrow = length(steps), ncol = nrow(pix_cat_df))

# Loop over all steps (note: this takes about 1 hour for 1 year of data)
for (i in 1:length(steps)) { 
  # print percentage progress
  print(round(i / length(steps) * 100))
  
  # construct the correct file name with minutes
  file = paste0("RFCOR/P_all/", folder_day[i], "/", "RAD_NL25_RAC_RF_", steps[i], ".h5") 
  
  if (file.exists(file)) {
    
    # Read HDF5 data
    P_all = h5read(file, name = "/image1/image_data")   
    
    # Select pixels in catchment
    P_cat[i,] = P_all[cbind(pix_cat_df$col, pix_cat_df$row)]
    
    # Close hdf5 file
    H5close()
    
  } else {
    
    # Print a message if the file does not exist
    print(paste("File", file, "does not exist!") )
    
  }
}



################
# Postprocessing
################

# Replace no-data value with NA
P_cat[P_cat == 65535] = NA  

# Convert to mm
P_cat_5min = P_cat / 100

# Aggregate to hourly values (values after timestamp: 8:00 is sum of values between 8:00 and 8:55)
hours = steps %/% 100
P_cat_hour = aggregate(P_cat_5min, by=list(hours), FUN=sum)[,2:(ncol(P_cat_5min)+1)]

# Compute catchment average
P_ave_5min = round(rowMeans(P_cat_5min),4)
P_ave_hour = round(rowMeans(P_cat_hour),4)

# write data to file
write.table(data.frame(date = steps, P = P_cat_5min), paste0("RFCOR/P_catchment/P_", cat_ID, "_5min.dat"), 
            row.names=F, col.names = c("date", paste0("pix",pix_cat_df$ID)))
write.table(data.frame(date = P_cat_hour[,1], P = P_cat_hour), paste0("RFCOR/P_catchment/P_", cat_ID, "_hour.dat"), 
            row.names=F, col.names = c("date", paste0("pix",pix_cat_df$ID)))
write.table(data.frame(date = steps, P = P_ave_5min), paste0("RFCOR/P_catchment/P_", cat_ID, "_5min_ave.dat"), row.names=F)
write.table(data.frame(date = P_cat_hour[,1], P = P_ave_hour), paste0("RFCOR/P_catchment/P_", cat_ID, "_hour_ave.dat"), row.names=F)


