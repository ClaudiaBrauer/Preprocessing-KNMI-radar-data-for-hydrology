

#################
# Getting started
#################

# Clear workspace
rm(list=ls())

# Set working directory 
setwd("C:/KNMI/")

# Uncomment to install packages if needed.
# To install rhdf5 package without having to install Rtools first:
# install.packages("BiocManager")
# BiocManager::install("rhdf5")

# Load packages
library(terra)      
library(sf)         
library(rhdf5)



########################
# Coordinates all pixels
########################

# Load ascii file with dataframe with radar pixel coordinates (in lat-lon)
pix_all_df = read.table("RAC/coordinates/radarcoordinaten_NL25_1km2_RD.txt")  

# Convert to spatial object (SpatVect class): put x and y in dataframe, set projection
pix_all_df$ID = 1:nrow(pix_all_df)
pix_all_sp = vect(cbind(longitude = pix_all_df[,3]*1000, latitude = pix_all_df[,4]*1000), 
                 atts = data.frame(ID = pix_all_df$ID, drow = pix_all_df[,1], dcol = pix_all_df[,2]), 
                 crs="+init=epsg:28992")

# Check (don't plot because too heavy)
pix_all_sp


################
# Catchment area
################

# Load border NL
NL_RD = vect("catchment_boundary/NL_border.shp", crs="+init=epsg:28992")  

# Reproject
NL_latlon = terra::project(NL_RD, "+proj=longlat +datum=WGS84")
NL_latlon

# Plot country map
plot(NL_latlon, border="grey")

# Define ID of catchment
cat_ID = "Aa"

# Option 1 :Load shapefile with catchment boundary (in RD coordinates)
cat_RD = vect(paste0("catchment_boundary/", cat_ID, "_catchment_boundary.shp"), 
              crs="+init=epsg:28992")  

# Change coordinate system RD to LatLon
cat_latlon = terra::project(cat_RD, "+proj=longlat +datum=WGS84")

# Option 2: Define x and y coordinates of the extent
# Order of arguments: xmin, xmax, ymin, ymax
# cat_latlon = vect(ext(3.3, 7.5, 50.7, 53.6), crs="+proj=longlat +datum=WGS84")

# Check
cat_latlon
lines(cat_latlon, col="darkblue")



############################
# Select pixels in catchment
############################

# Cut out the pixels within the catchment
pix_cat_sp = intersect(pix_all_sp, cat_RD)

# Check
pix_cat_sp

# Make dataframe with the ID, lat and lon, row and col
pix_cat_df     = data.frame(ID = pix_cat_sp$ID)
pix_cat_df$lat = crds(pix_cat_sp)[,2]
pix_cat_df$lon = crds(pix_cat_sp)[,1]
pix_cat_df$row = pix_cat_sp$drow
pix_cat_df$col = pix_cat_sp$dcol

# Write to file
write.table(pix_cat_df, paste0("RFCOR/coordinates/pixels_", cat_ID, ".dat"), row.names=F)

# Reproject to latlon
pix_cat_RD = vect(pix_cat_df, crs="+init=epsg:28992")
pix_cat_latlon = terra::project(pix_cat_RD, "+proj=longlat +datum=WGS84")

# Add pixels to map
points(pix_cat_latlon, cex=0.1, col="dodgerblue")

# Write to file
write.table(pix_cat_df,paste0("RAC/coordinates/pixels_",cat_ID, ".dat"),row.names=F)

# Save figure to file
pdf(paste0("RAC/coordinates/map_",cat_ID,".pdf"), width=5, height=6, family="Times")
plot(NL_latlon, border="grey", main=paste("RAC pixels",cat_ID), xlab="Lon", ylab="Lat")
lines(cat_latlon, col="darkblue")
points(pix_cat_latlon, cex=0.1, col="dodgerblue")
graphics.off()



################
# Read HDF5 data
################

# Specify for which year
year = 2021

# Make vector with all 1 hour intervals in that year
steps = seq(from = ISOdatetime(year, 1, 1, 0, 0, 0, tz = "UTC"),
           #to = ISOdatetime(year + 1, 1, 1, 0, 0, 0, tz = "UTC"), #  COMMENTED FOR TESTING A 3-MONTH PERIOD -> REMOVE #
           to = ISOdatetime(year, 3, 1, 0, 0, 0, tz = "UTC"),      # FOR TESTING -> REMOVE LINE
           by = "5 min")
# Cut off last value (is first value of next year)
steps = steps[1:(length(steps)-1)]

# Transform into 'YYYYmmddHHMM' format
steps = as.numeric(format(steps, "%Y%m%d%H%M"))

# Also subtract month (as character because leading zero needed)
month = substr(steps, 5, 6)

# Make matrix for precipitation of all hours (rows) and all pixels (cols)
P_cat = matrix(nrow = length(steps), ncol = nrow(pix_cat_df))

# Loop over all steps
for (i in 1:length(steps)) { 
  # print percentage progress
  print(round(i / length(steps) * 100))
  
  # construct the correct file name with minutes
  file = paste0("RAC/P_all/",year, "/", month[i],
                  "/RAD_NL25_RAC_MFBS_5min_", steps[i], "_NL.h5") 
  
  if (file.exists(file)) {
    
    # Read HDF5 data
    P_all = h5read(file, name = "/image1/image_data")   
    
    # Select pixels in catchment
    P_cat[i,] = P_all[cbind(pix_cat_df$col, pix_cat_df$row)]
    
    # Close hdf5 file
    H5close()
    
  } else {
    
    # Print a message if the file does not exist
    print("File does not exist!")  
    
  }
}



################
# Postprocessing
################

# Replace no-data value with NA
P_cat[P_cat == 65535] = NA  

# Convert to mm
P_cat_mm = P_cat / 100

# write data to file
write.table(data.frame(date = steps, P = P_cat_mm), paste0("RAC/P_catchment/P_", cat_ID, ".dat"), 
            row.names=F, col.names = c("date", paste0("pix",pix_cat_df$ID)))

# Compute catchment average
P_ave = round(rowMeans(P_cat))/100

# Write catchment average to file
write.table(data.frame(date = steps, P = P_ave), paste0("RAC/P_catchment/P_", cat_ID, "_ave.dat"), row.names=F)



