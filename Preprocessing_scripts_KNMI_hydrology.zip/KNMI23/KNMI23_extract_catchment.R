
# GEEFT NOG NA ALS UITKOMST!



#################
# Getting started
#################

# Clear workspace
rm(list=ls())

# Set working directory 
setwd("C:/KNMI")

# Load packages
library(terra)      
library(sf)         
library(ncdf4)


########################
# extract timeseries
########################

# set scenarios
variables = c("P","ETpot")         # options: P and ETpot
variables_filename = c("Pr","pet") # options: Pr = precipitation, pet = ETpot
years = c(2050,2100,2150)         # options: 2033, 2050, 2100, 2150. Note: for the L scenarios only 2100 (because the same as 2050 and 2150)
scenarios = c("H","M","L")         # options: H = high, M = moderate, L = low
variants = c("n","d")              # options: n = wet, d = dry

# set scenarios
variables = c("P")           # options: P and ETpot
variables_filename = c("Pr") # options: Pr = precipitation, pet = ETpot
years = c(2050)              # options: 2033, 2050, 2100, 2150. Note: for the L scenarios only 2100 (because the same as 2050 and 2150)
scenarios = c("H")           # options: H = high, M = moderate, L = low
variants = c("n")            # options: n = wet, d = dry

 for(iVariable in 1:length(variables)){
   variable = variables[iVariable]
   variable_filename = variables_filename[iVariable]
   
   for(iYear in 1:length(years)){
     year = years[iYear]
     
     for(iScenario in 1:length(scenarios)){
       scenario = scenarios[iScenario]
       
       if((scenario=="L" & year==2050) | (scenario=="L" & year==2150)) { 
         # Skip these because for the L scenarios only 2100 (because the same as 2050 and 2150)
         
       }else{
         
         for(iVariant in 1:length(variants)){
            variant = variants[iVariant]
             
            # Make file name
            filename = paste0("KNMI23/PE_all/", variable_filename, "_", scenario, variant, "_", year, "_interp.nc")
            print(filename)
            
            # Read NetCDF file and store in netcdf class (called ncdf4)
            d_nc = nc_open(filename)
            
            # Extract the data to a 4-dimensional matrix:
            # Dimension 1: 37 points for longitude: 2.9-7.4 degrees E
            # Dimension 2: 32 points for latitude: 50.6-53.7 degrees N
            # Dimension 3: 8 ensemble members
            # Dimension 4: 10957 time steps: 30 years of daily values
            d_all = ncvar_get(d_nc)
            
            # Make vectors for all ranges
            lons = round(seq(2.9, 7.4, length.out=37),2)
            lats = seq(50.6, 53.7, by=0.1)
            enss = 1:8
            times_as_date = seq(as.Date(paste0(year-14,"0101"), format="%Y%m%d"),
                        as.Date(paste0(year+15,"1231"), format="%Y%m%d"), by="day")
            times = as.numeric(format(times_as_date, format="%Y%m%d"))
            
            # Compute length
            nLon = length(lons)
            nLat = length(lats)
            nEns = length(enss)
            nTimes = length(times)
            
            
            ########################
            # Coordinates all pixels
            ########################
            
            # Make spatial object for pixels
            pix_all_sp = vect(cbind(longitude = rep(lons,nLat), 
                                    latitude = rep(lats, each=length(lons))), 
                              atts = data.frame(idx_lon = rep((1:nLon), nLat), 
                                                idx_lat = rep((1:nLat), each=nLon)), 
                              crs="+proj=longlat +datum=WGS84")
            
            # Check and plot
            pix_all_sp
            plot(pix_all_sp, col="grey", cex=0.7, pch="+")
            
            
            # Add border Netherlands to the map
            
            # Load border NL
            NL_RD = vect("catchment_boundary/NL_border.shp", crs="+init=epsg:28992")  
            
            # Reproject
            NL_latlon = terra::project(NL_RD, "+proj=longlat +datum=WGS84")
            NL_latlon
            
            # Add to map
            lines(NL_latlon, col="darkblue")
            
            
            
            ################
            # Catchment area
            ################
            
            # Define ID of catchment
            cat_ID = "Aa"
            
            # Option 1 :Load shapefile with catchment boundary (in RD coordinates)
            cat_RD = vect(paste0("catchment_boundary/", cat_ID, "_catchment_boundary.shp"), 
                          crs="+init=epsg:28992")  
            
            # Change coordinate system RD to LatLon
            cat_latlon = terra::project(cat_RD, "+proj=longlat +datum=WGS84")
            
            # Option 2: Define x and y coordinates of the extent
            # Order of arguments: xmin, xmax, ymin, ymax
            # cat_latlon = vect(ext(3.3, 7.5, 50.7, 53.6), crs="+proj=longlat +datum=WGS84")
            
            
            # Check
            cat_RD
            
            # Reproject
            cat_latlon = terra::project(cat_RD, "+proj=longlat +datum=WGS84")
            cat_latlon
            
            # Add to map
            lines(cat_latlon, col="orange")
            
            
            
            ############################
            # Select pixels in catchment
            ############################
            
            # Cut out the pixels within the catchment
            pix_cat_sp = intersect(pix_all_sp, cat_latlon)
            
            # Check
            pix_cat_sp
            points(pix_cat_sp, col = "red", pch="+", cex=0.7)
            
            # Make dataframe with the ID (index number), lat and lon
            pix_cat_df     = data.frame(idx_lon = pix_cat_sp$idx_lon, idx_lat = pix_cat_sp$idx_lat)
            pix_cat_df$lon = crds(pix_cat_sp)[,1]
            pix_cat_df$lat = crds(pix_cat_sp)[,2]
            
            # Count number of pixels in catchment
            nPix = nrow(pix_cat_df)
            
            # Write coordinates and figure to file (only necessary once)
            if(iVariable == 1 & iYear == 1 & iScenario == 1 & iVariant == 1){
            
              # Write to file
              write.table(pix_cat_df, paste0("KNMI23/coordinates/pixels_", cat_ID, ".dat"), row.names=F)
              
              # Save figure to file
              pdf(paste0("KNMI23/coordinates/map_",cat_ID,".pdf"), width=5, height=6, family="Times")
              plot(pix_all_sp, col="grey", cex=0.7, pch="+", main=paste("KNMI'23 pixels",cat_ID), xlab="Lon", ylab="Lat")
              lines(NL_latlon, col="darkblue")
              lines(cat_latlon, col="orange")
              points(pix_cat_sp, col = "red", pch="+", cex=0.7)
              graphics.off()
           }
            
            
            
            #####################
            # Extract time series
            #####################
            
            # Make matrix for P or ET of all days (rows) and all pixels (cols)
            d_cat = matrix(nrow = nTimes * nEns, ncol = nPix)
            
            # Loop over all pixels
            for (iPix in 1:nPix) { 
              
              # Loop over all ensemble members
              for(iEns in 1:nEns){
                
              # Select pixels in catchment
             # d_cat[((iEns-1)*nTimes+1) : (iEns*nTimes), iPix] = 
            #     d_cat[((iEns-1)*nTimes+1) : (iEns*nTimes), iPix]
              
                #### HIER GAAT HET MIS
                # OOK VERDEROP BIJ LOC (UITGECOMMENTARIEERD)
                
              d_cat[(((iEns-1)*nTimes)+1) : (iEns*nTimes), iPix] = 
                d_all[pix_cat_df$idx_lon[iPix], pix_cat_df$idx_lat[iPix], iEns,]
              
                
              }
            }
            
            
            
            ################
            # Postprocessing
            ################
            
            
            # Compute catchment average
            d_ave = round(rowMeans(d_cat),3)
            
            # write data to file
            write.table(data.frame(date = rep(times, nEns), ens = rep(enss, each = nTimes), d_cat), 
                        paste0("KNMI23/PE_catchment/", variable, "_", scenario, variant, "_", year,
                               "_", cat_ID, "_day.dat"), 
                        row.names=F, col.names = c("date", "ens", paste0("pix", 1:nPix)))
            write.table(data.frame(date = rep(times, nEns), ens = rep(enss, each = nTimes), d_ave), 
                        paste0("KNMI23/PE_catchment/", variable, "_", scenario, variant, "_", year,
                               "_", cat_ID, "_day_ave.dat"), 
                        row.names=F, col.names = c("date", "ens", variable))
            
            
            
            # ###############################################
            # # Alternative: extract pixel closest to a point
            # ###############################################
            # 
            # # Location Hupsel
            # loc_ID  = "point_Hupsel"
            # lon_loc = 6.66
            # lat_loc = 52.06
            # 
            # # Find closest pixel
            # lon_idx = which.min(abs(lons - lon_loc))
            # lat_idx = which.min(abs(lats - lat_loc))
            # 
            # # Make vector for P or ET of all days (rows)
            # d_loc = array(dim = nTimes * nEns)
            # 
            # # Loop over all ensemble members
            # for(iEns in 1:nEns){
            #     
            #     # Select pixel near location
            #     d_loc[((iEns-1)*nTimes+1) : (iEns*nTimes)] = 
            #       round(d_all[lon_idx, lat_idx, iEns, ], 3)
            # }
            # 
            # # Write output to file
            # write.table(data.frame(date = rep(times, nEns), ens = rep(enss, each = nTimes), d_loc), 
            #             paste0("KNMI23/PE_catchment/", variable, "_", scenario, variant, "_", year,
            #                    "_", loc_ID, "_day.dat"), 
            #             row.names=F, col.names = c("date", "ens", variable))
    
  

         # End loops over variants, scenarios, years, variables
         }
       }
     }
   }
 }

