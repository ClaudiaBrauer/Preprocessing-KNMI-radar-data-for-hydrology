#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Python script to download files from the KNMI Data Platform (KDP) for a range of dates: https://dataplatform.knmi.nl/
# Based on an example script from https://developer.dataplatform.knmi.nl/example-scripts
# and expanded by Aart Overeem and Claudia Brauer.
# To use:
# Change the directory (L. 31) to the folder where the downloaded files will be stored
# and specify which files you want (L.34-39).
# Then run line by line (F9). Result is a folder per day with h5 files (of each 5 minutes)
# (and a tar file per day if you comment L. 90). 

# Import Python libraries:
import logging
import sys
from datetime import datetime
from pathlib import Path
import os
import tarfile


import requests
from datetime import timedelta

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel("INFO")

api_url = "https://api.dataplatform.knmi.nl/open-data"
api_version = "v1"

# SET WORKING DIRECTORY HERE (no spaces allowed)
os.chdir("C:/radar/RTCOR/P_all")

# CHANGE WHICH FILES YOU WANT HERE
# api_key = "eyJvcmciOiI1ZTU1NGUxOTI3NGE5NjAwMDEyYTNlYjEiLCJpZCI6ImE1OGI5NGZmMDY5NDRhZDNhZjFkMDBmNDBmNTQyNjBkIiwiaCI6Im11cm11cjEyOCJ9" # public key (Jan 2024)
api_key = "eyJvcmciOiI1ZTU1NGUxOTI3NGE5NjAwMDEyYTNlYjEiLCJpZCI6ImVhNWM0NzcyMzA0YjRhMzQ4M2M1ODNmYWQ3Njg5NjkxIiwiaCI6Im11cm11cjEyOCJ9" # Claudia's personal key
dataset_name = "nl_rdr_data_rtcor_5m_tar" 
dataset_version = "1.0"
filename_prefix = "RAD25_OPER_R___TARRRF__L2__" 
start_day = "20230421"
end_day = "20240101"

# Convert to date-time class
date_current = datetime.strptime(start_day, "%Y%m%d") 
date_end = datetime.strptime(end_day, "%Y%m%d") 
print(date_current, date_end)

# Loop over timesteps 
while date_current <= date_end:
    
    start_after_filename_prefix = filename_prefix + datetime.strftime(date_current,"%Y%m%d") + "*"
    print(start_after_filename_prefix)
    list_files_response = requests.get(
        f"{api_url}/{api_version}/datasets/{dataset_name}/versions/{dataset_version}/files",
        headers={"Authorization": api_key},
        params={"maxKeys": 1, "startAfterFilename": start_after_filename_prefix},
    )
    list_files = list_files_response.json()

    logger.info(f"List files response:\n{list_files}")
    dataset_files = list_files.get("files")

    # Retrieve first file in the list files response
    filename = dataset_files[0].get("filename")
    logger.info(f"Retrieve file with name: {filename}")
    endpoint = f"{api_url}/{api_version}/datasets/{dataset_name}/versions/{dataset_version}/files/{filename}/url"
    get_file_response = requests.get(endpoint, headers={"Authorization": api_key})
    if get_file_response.status_code != 200:
        logger.error("Unable to retrieve download url for file")
        logger.error(get_file_response.text)
        sys.exit(1)

    download_url = get_file_response.json().get("temporaryDownloadUrl")
    dataset_file_response = requests.get(download_url)
    if dataset_file_response.status_code != 200:
        logger.error("Unable to download file using download URL")
        logger.error(dataset_file_response.text)
        sys.exit(1)

    # Write dataset file to disk
    p = Path(filename)
    p.write_bytes(dataset_file_response.content)
    logger.info(f"Successfully downloaded dataset file to {p}")
    
    # Extract tar into separate folder
    tar = tarfile.open(p)
    yyyymmdd = date_current.year * 10000 + date_current.month * 100 + date_current.day
    tar.extractall(os.getcwd() + "/" + str(yyyymmdd))
    tar.close()
    
    # Delete tar (comment if you want to keep the tar files)
    Path.unlink(filename)
    
    # Determine next day:
    date_current = date_current + timedelta(days=1)


