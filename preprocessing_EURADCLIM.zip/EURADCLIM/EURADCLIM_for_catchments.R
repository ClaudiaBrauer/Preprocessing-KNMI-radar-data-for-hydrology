

#################
# Getting started
#################

# Clear workspace
rm(list=ls())

# Set working directory 
setwd("C:/KNMI/EURADCLIM")

# Uncomment to install packages if needed.
# To install rhdf5 package without having to install Rtools first:
# install.packages("BiocManager")
# BiocManager::install("rhdf5")

# Load packages
library(terra)      
library(sf)         
library(rhdf5)



########################
# Coordinates all pixels
########################

# Load ascii file with dataframe with radar pixel coordinates (in lat-lon)
pix_all_df = read.table("EURADCLIM/coordinates/CoordinatesHDF5ODIMWGS84.dat")  

# Convert to spatial object (SpatVect class): put x and y in dataframe, set projection
pix_all_df$ID = 1:nrow(pix_all_df)
pix_all_sp = vect(cbind(longitude = pix_all_df[,1], latitude = pix_all_df[,2]), 
                  atts = data.frame(ID = pix_all_df$ID), 
                  crs="+proj=longlat +datum=WGS84")

# Check (don't plot because too heavy)
pix_all_sp



################
# Catchment area
################

# Define ID of catchment
cat_ID = "Aa"

# Load shapefile with catchment boundary (in RD coordinates)
cat_RD = vect(paste0("catchment_boundary/", cat_ID, "_catchment_boundary.shp"), 
              crs="+init=epsg:28992")    

# Test with extent NL
NL_latlon = ext(3.3, 7.5, 51.1, 53.4)


# Change coordinate system RD to LatLon
cat_latlon = terra::project(cat_RD, "+proj=longlat +datum=WGS84")

# Check
cat_latlon
plot(cat_latlon)

plot(NL_latlon)
lines(cat_latlon)



############################
# Select pixels in catchment
############################

# Cut out the pixels within the catchment
pix_cat_sp = intersect(pix_all_sp, cat_latlon)

# Check
pix_cat_sp
points(pix_cat_sp, cex=0.01, col="red")

# Convert to row and col number
# 1. Define no of rows and cols in H5 file
nrows_H5 = 2200
ncols_H5 = 1900

# 2. Make dataframe with the ID, lat and lon
pix_cat_df     = data.frame(ID = pix_cat_sp$ID)
pix_cat_df$lat = crds(pix_cat_sp)[,2]
pix_cat_df$lon = crds(pix_cat_sp)[,1]

# 3. Compute in which row and column the selected pixels are
pix_cat_df$row = pix_cat_df$ID%/%ncols_H5 + 1   # %/% means integer division (remainder discarded after division)
pix_cat_df$col = pix_cat_df$ID%%ncols_H5        # %% means modulo (the remainder after integer division)
# Correct the ones that should be in the last column
pix_cat_df$row[pix_cat_df$col == 0] = pix_cat_df$row[pix_cat_df$col == 0] - 1
pix_cat_df$col[pix_cat_df$col == 0] = ncols_H5

# Write to file
write.table(pix_cat_df,paste0("EURADCLIM/coordinates/pixels_",cat_ID, ".dat"),row.names=F)



################
# Read HDF5 data
################

# Specify for which year
year = 2020

# Make vector with all 1 hour intervals in that year
hour = seq(from = ISOdatetime(year, 1, 1, 0, 0, 0, tz = "UTC"),
           to = ISOdatetime(year + 1, 1, 1, 0, 0, 0, tz = "UTC"),
           by = "1 hour")

# Cut off last value (is first hour of next year)
hour = hour[1:(length(hour)-1)]

# Transform into 'YYYYmmddHHMM' format
hour = as.numeric(format(hour, "%Y%m%d%H%M"))

# Also subtract month (as character because leading zero needed)
month = substr(hour, 5, 6)

# Make matrix for precipitation of all hours (rows) and all pixels (cols)
P_cat = matrix(nrow = length(hour), ncol = nrow(pix_cat_df))

# Loop over all hours
for (i in 1:length(hour)) { # UNCOMMENT AFTER TESTING
  #  for (i in 1:1) {           # REMOVE AFTER TESTING
  # print percentage progress
  print(round(i / length(hour) * 100))
  
  # construct the correct file name with minutes
  file = paste0("EURADCLIM/P_all/",year, "/", month[i],
                "/RAD_OPERA_HOURLY_RAINFALL_ACCUMULATION_", hour[i], ".h5") # UNCOMMENT AFTER TESTING
  
  if (file.exists(file)) {
    
    # Read HDF5 data
    P_all = h5read(file, name = "/dataset1/data1/data")   
    
    # Select pixels in catchment
    P_cat[i,] = P_all[cbind(pix_cat_df$col, pix_cat_df$row)]
    # Comment from Romy: RHDF5 package reads radar as transposed matrix, so we have to reverse row and col!
    
    # Close hdf5 file
    H5close()
    
  } else {
    
    # Print a message if the file does not exist
    print("File does not exist!")  
    
  }
}



################
# Postprocessing
################

# Replace no-data value with NA
P_cat[P_cat == -9999000] = NA  

# Convert to mm
P_cat_mm = P_cat# / 100

# write data to file
write.table(data.frame(date = hour, P = P_cat_mm), paste0("EURADCLIM/P_catchment/P_", cat_ID, ".dat"), 
            row.names=F, col.names = c("date", paste0("pix",pix_cat_df$ID)))

# Compute catchment average
P_ave = round(rowMeans(P_cat))

# Write catchment average to file
write.table(data.frame(date = hour, P = P_ave), paste0("EURADCLIM/P_catchment/P_", cat_ID, "_ave.dat"), row.names=F)



